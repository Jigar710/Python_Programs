from django.apps import AppConfig


class QuizappConfig(AppConfig):
    name = 'quizapp'
