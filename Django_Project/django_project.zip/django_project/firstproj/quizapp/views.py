from django.shortcuts import render
from django.http import HttpResponse

def addition(request):
	try:
		'''
		print("before")
		print("Request object :",request)
		
		for i in dir(request):
			if '_' not in i:
				print(i)
				
		print("after")
		'''
		a = int(request.GET['t1'])
		b = int(request.GET['t2'])
		
		#print(a,b)
		c = a + b
		#print(c)
		
		return HttpResponse("Addition :"+str(c))
	except:
		return HttpResponse("invalid arguments")
	
def substraction(request):
	try:
		'''
		print("before")
		print("Request object :",request)
		
		for i in dir(request):
			if '_' not in i:
				print(i)
				
		print("after")
		'''
		a = int(request.GET['t1'])
		b = int(request.GET['t2'])
		
		#print(a,b)
		c = a - b
		#print(c)
		
		return HttpResponse("Sub :"+str(c))
	except:
		return HttpResponse("invalid arguments")